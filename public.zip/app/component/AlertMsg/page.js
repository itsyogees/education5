import React from 'react'

const AlertMsg = () => {
  return (
    <div>AlertMsg</div>
  )
}

export default AlertMsg